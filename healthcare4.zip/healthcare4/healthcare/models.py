import pymysql
from . import models
from django.shortcuts import redirect,render

def connect():
    con = pymysql.connect(host='byjfjadn7lpacn4zhrum-mysql.services.clever-cloud.com',user='ufzye7gqd7rzxryx', password='E6do0BeEBKEbqhFclCCY',database='byjfjadn7lpacn4zhrum')
    return con
def getCities(state="NA"):
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute("select city from cities where state='"+state+"'")
    data=cursor.fetchall()
    conn.close()
    return data
def getStates():
    conn = connect()
    #integrated security 
    cursor = conn.cursor() 
    cursor.execute('select state from statemaster;')
    data=cursor.fetchall()
    conn.close()
    return data
def Cities(request):
    data= models.getCities(request.GET.get("state"))    
    return render(request, "cities.html",{"list":data})
class HealthCareOperations:
    
    def checkuser(self,unm,ps):
        # Establish a connection to the database
        con = connect()
        curs = con.cursor()
        curs.execute("select * from Users where user_id='%s' and password='%s'" %(unm, ps))
        data = curs.fetchone()  
        con.close()
        return data
  


    def adduser(self, id, un, eid, rol, pw, mob, logstat, crdt):
        try:
           con = connect()
           curs = con.cursor()
           curs.execute("INSERT INTO Users (user_id, username, email, password, role, login_status, mobileno, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",(id, un, eid, pw, rol, logstat, mob, crdt))
           con.commit()
           msg = "User added Successfully"
           con.close()
        except Exception as e:
          print(e)
          msg = "Failed to add User"

        return msg



# def newuser(self,id,ps):
#         con=pymysql.connect(host='byjfjadn7lpacn4zhrum-mysql.services.clever-cloud.com', user='ufzye7gqd7rzxryx', password='E6do0BeEBKEbqhFclCCY', database='byjfjadn7lpacn4zhrum')
#         curs=con.cursor()
#         curs.execute("select role from Users where user_id='%s' and password='%s'" %(id,ps))
#         data=curs.fetchone()
#         if data:
#             page="Admin.html"
#         else:
#             page="Failure.html"
#         con.close()
#         return page      


    def addHCSP(self,sid,hsn, sd, add, st, ci, pc, cn, cp, pd, rt, tpc, tnc, tnuc, ct,uid1):
        try:
           con = connect()
           curs = con.cursor()
           curs.execute("INSERT INTO HealthCare_Services (service_id, healthcare_service_name, service_desc, addr, state, city, pincode, contact_no, contact_person, proof_docs, rating, total_positive_comments, total_negative_comments, total_neutral_comments, category, user_id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                        (sid, hsn, sd, add, st, ci, pc, cn, cp, pd, rt, tpc, tnc, tnuc, ct, uid1))
           con.commit()
           msg = "HealthCare Service Provider added Successfully"
           con.close()
        except Exception as e:
          print(e)
          msg = "Failed to add HealthCare Service Provider"

        return msg

    def getallUser(self):
      con = connect()
      curs=con.cursor()
      curs.execute("select user_id, username, email, login_status, mobileno, created_at from Users where role='User'")
      data=curs.fetchall()
      con.close()
      return data

    def getallActiveHCSP(self):
      con = connect()
      curs=con.cursor()
      curs.execute("SELECT h.healthcare_service_name, h.service_desc, h.addr, h.state, h.city, h.pincode, h.contact_no, h.contact_person, h.proof_docs, h.rating, h.category, u.email  From HealthCare_Services h INNER JOIN Users u ON h.user_id = u.user_id and u.login_status = 'active'")
      data=curs.fetchall()
      con.close()
      return data

    def getallPendingHCSP(self):
     con = connect()
     curs=con.cursor()
     curs.execute("SELECT h.healthcare_service_name, h.service_desc, h.addr, h.state, h.city, h.pincode, h.contact_no, h.contact_person, h.proof_docs, h.rating, h.category, u.email, u.user_id  From HealthCare_Services h INNER JOIN Users u ON h.user_id = u.user_id and u.login_status = 'Pending'")
     data=curs.fetchall()
     con.close()
     return data
    
    def getallactivateHCSP(self, userid):
     con = connect()
     curs=con.cursor()
     curs.execute("Update Users set login_status='active' where user_id = '%s'" %(userid))
     con.commit()
     data=curs.fetchall()
     con.close()
     return data
     
    def searchHosp(self, state, city, category):
        con = connect()
        curs=con.cursor()
        qr="SELECT h.healthcare_service_name, h.service_desc, h.addr, h.state, h.city, h.pincode, h.contact_no, h.contact_person, h.proof_docs, h.rating, h.category, h.user_id, u.email FROM HealthCare_Services h INNER JOIN Users u ON h.user_id = u.user_id WHERE u.login_status = 'active' AND h.state ='"+state+"' AND h.city = '"+city+"' AND h.category = '"+category+"'"
        print(qr)
        curs.execute(qr)
        data=curs.fetchall()
        
        #print("db")
        print(data)
        con.close()
        return data
    


    def submit_feedback(self, user_id, rating,comments):
        try:
           con = connect()
           curs = con.cursor()
           username = 'vaishnavi'
           service_id = 7017
           healthcare_service_name = 'sumedh labs'
           date_visited = '24-05-16'
           submitted_at = '24-05-30'
           polarity = 3.5
           sentiment = 'good'
           curs.execute("INSERT INTO feedbacks (user_id, username, service_id, healthcare_service_name, rating, comment, date_visited, submitted_at, polarity, sentiment) VALUES (%s, %s, %d, %s, %d, %s, %s, %s, %s,%s)",(user_id, username, service_id, healthcare_service_name, rating,comments, date_visited, submitted_at, polarity, sentiment))
           con.commit()
           msg = "Reviews submitted Successfully!.."
           con.close()
        except Exception as e:
          print(e)
          msg = "Failed to submit reviews"

        return msg
   

    
       
    
def handle_uploaded_file(f,userid):
    nm,ext,os=os.path.basename(f.name).split('.')
    print("nm="+nm+" "+ext)
    with open('../healthcare1/static/Documents/'+userid+"."+ext, 'wb+') as destination:  
        for chunk in f.chunks():  
            destination.write(chunk)      
    return userid+"."+ext





