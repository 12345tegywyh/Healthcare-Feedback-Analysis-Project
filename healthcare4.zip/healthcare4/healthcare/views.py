from django.shortcuts import redirect,render
from django.contrib.auth import authenticate, login as auth_login
# import pymysql
from .models import HealthCareOperations
from datetime import datetime
from . import models


# from django.http import HttpResponse
# from .models import HealthcareService


def home(request):
  return render(request,'home.html')


def login(request):
    page=None

    if request.method=="POST":
        unm=request.POST.get("username")
        ps=request.POST.get("password")
         
        obj=HealthCareOperations()
        data=obj.checkuser(unm,ps)
        page="Failure.html"
        request.session["userid"]=data[0] 
        request.session["utype"]=data[4] 
        request.session["username"]=data[1] 
        request.session["email"]=data[2]
        data1= models.getStates()
        if(len(data)>0):
            if(data[4].strip().lower()=="user"): 
                page="User.html"
            elif(data[4].strip().lower()=="admin"):
                page="Admin.html"
            elif(data[4].strip().lower()=="helthcare"):
                page="Healthcare.html"
            else:
                page="Failure.html"
        else:
            page="Failure.html"
        # request.session['users']=id
    return render(request, page,{"list":data1}) 
    
def Cities(request):
    data= models.getCities(request.GET.get("state"))    
    return render(request, "cities.html",{"list":data})


def logout(request):
    del request.session["userid"]
    del request.session["utype"]
    del request.session["username"]  
    del request.session["email"] 
    return render(request, "home.html")

def Register(request):
    return render(request,"UserReg.html")


def adduser(request):
    msg = None
    dic = {}  
    
    if request.method == "POST":
        try:
            id = int(request.POST.get("userid"))
            un = request.POST.get("username")
            eid = request.POST.get("email")
            rol = request.POST.get("role")
            pw = request.POST.get("password")
            mob = request.POST.get("mobile")
            logstat = "active"  
            crdt = datetime.now().strftime('%Y-%m-%d') 
            obj = HealthCareOperations()
            msg = obj.adduser(id, un, eid, rol, pw, mob, logstat, crdt)
        except Exception as e:
            print(e)
            msg = 'Error in insert'
        
    dic['status'] = msg  
    return render(request, "Newuser.html", dic)


def HCSPRegister(request):
    return render(request,"HealthCare_service_Reg.html")

def addHCSP(request):
    msg = None
    msg1= None
    dic = {}  
    
    if request.method == "POST":
        try:
            uid=int(request.POST.get("user_id"))
            hsn = request.POST.get("healthcare_service_name")
            sd = request.POST.get("service_desc")
            add = request.POST.get("addr")
            st = request.POST.get("state")
            ci = request.POST.get("city")
            pc = request.POST.get("pincode")
            cn = request.POST.get("contact_no")
            cp = request.POST.get("contact_person")
            pd = request.POST.get("proof_docs")
            rt = request.POST.get("rating")
            email = request.POST.get("email")
            tpc = request.POST.get("total_positive_comments")
            tnc = request.POST.get("total_negative_comments")
            tnuc = request.POST.get("total_neutral_comments")
            ct = request.POST.get("category")
            uid1=int(request.POST.get("user_id"))
            #logstat = "active" 
            
            rol="HealthCare"
            pw=""
            crdt = datetime.now().strftime('%Y-%m-%d') 
            lstatus="Pending"
            obj = HealthCareOperations()
            msg = obj.addHCSP(uid, hsn, sd, add, st, ci, pc, cn, cp, pd, rt, tpc, tnc, tnuc, ct,uid1)
            msg1 = obj.adduser(uid, uid, email, rol, pw, cn, 'pending', crdt)
        except Exception as e:
            print(e)
            msg = 'Error in adding to HCSP table'
            msg1 = 'Error in Adding to Users table'
        
    dic['status'] = msg  
    dic['status1'] = msg1  

    return render(request, "HCstaus.html", dic)

def allUser(request):
    dic={}
    obj=HealthCareOperations()
    data=obj.getallUser()
    #user=request.session['user']
    return render(request,"UserReport.html",{'userdata':data})

def allActiveHCSP(request):
    dic={}
    obj=HealthCareOperations()
    data=obj.getallActiveHCSP()
    #user=request.session['user']
    return render(request,"HCSActiveStatusReport.html",{'HCSPdata':data})

def allPendingHCSP(request):
    dic={}
    obj=HealthCareOperations()
    data=obj.getallPendingHCSP()
    #user=request.session['user']
    return render(request,"HCSPendingStatusReport.html",{'HCSPdata':data})

def allactivateHCSP(request, id):
    dic={}
    obj=HealthCareOperations()
    data=obj.getallactivateHCSP(id)
    request.session['id'] = id
    return render(request,"HSCPactivated.html",{'HCSPdata':data,'userid':id})

    photo=models.handle_uploaded_file(request.FILES['file'],userid)


def searchHosp(request):
    msg = None
    dic = {}  
    
    if request.method == "POST":
        try:
            state = request.POST.get("state")
            city = request.POST.get("city")
            category = request.POST.get("category")
            obj = HealthCareOperations()
            msg = obj.searchHosp(state, city, category)
            #request.session['id'] = id
            print(msg)
            data1= models.getStates()
        except Exception as e:
            print(e)
            msg = 'Error in searching Hospitals'
        
    #dic['status'] = msg  
    return render(request, "User.html", {'HCSPdata':msg,'list':data1})



def submit_reviews(request, id):
    dic={}
    obj = HealthCareOperations()
    request.session['id'] = id
    return render(request,"SubmitReviews.html",{'userid':id})

def submit_feedback(request, id ):
    if request.method == 'POST':
       dic={}
    
       userid = request.POST.get("userid")
       rating = request.POST.get("rating")
       comments = request.POST.get("comments")
       obj = HealthCareOperations()
       msg = obj.submit_feedback(userid, rating, comments)
       request.session['id'] = id
    
    return render(request,"feedback.html", {'userid':id, 'rating':rating, 'comments':comments, 'message': msg})
    


     


